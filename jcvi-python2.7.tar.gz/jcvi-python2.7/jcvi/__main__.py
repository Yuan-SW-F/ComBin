#!/usr/bin/env python
# -*- coding: UTF-8 -*-


from jcvi.apps.base import dmain


if __name__ == '__main__':
    dmain(__file__, type="module")
