__author__ = ("Haibao Tang", "Vivek Krishnakumar", "Jingping Li")
__copyright__ = "Copyright (c) 2010-2018, Haibao Tang"
__email__ = "tanghaibao@gmail.com"
__license__ = "BSD"
__status__ = "Development"
__version__ = "0.8.12"
